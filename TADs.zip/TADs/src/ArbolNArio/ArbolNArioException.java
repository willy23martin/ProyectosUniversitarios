package ArbolNArio;

@SuppressWarnings("serial")
public class ArbolNArioException extends Exception {

	public ArbolNArioException(String error){
		super(error);
	}
	
}

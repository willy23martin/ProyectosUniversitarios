package ListaRecursiva;

@SuppressWarnings("serial")
public class ListaRecursivaException extends Exception {

	public ListaRecursivaException(String e){
		super(e);
	}
	
}

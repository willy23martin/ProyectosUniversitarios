package ListaEnlazadaSimple;

@SuppressWarnings("serial")
public class ListaEnlazadaSimpleException extends Exception {

	public ListaEnlazadaSimpleException(String error){
		super(error);
	}
	
}

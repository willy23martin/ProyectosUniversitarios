package TablaHash;

@SuppressWarnings("serial")
public class ListaEnlazadaNodoHashException extends Exception {

	public ListaEnlazadaNodoHashException(String error){
		super(error);
	}
	
}

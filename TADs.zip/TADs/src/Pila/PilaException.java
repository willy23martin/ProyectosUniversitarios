package Pila;

@SuppressWarnings("serial")
public class PilaException extends Exception {

	public PilaException(String e){
		super(e);
	}
	
}

package ListaDoblementeEnlazada;

@SuppressWarnings("serial")
public class ListaDoblementeEnlazadaException extends Exception {

	public ListaDoblementeEnlazadaException(String error){
		super(error);
	}
	
}
